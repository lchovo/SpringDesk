SpringDesk press kit
https://springdesk.app/press/

SpringDesk is the desktop organizer made for Windows 11: clear glass boxes for your icons, new files that put themselves away, Space to look inside and typing to find anything. Buy once, no subscription.

Tagline: Clear glass. Clean desktop.

Developer:     Brock Loong
Released:      October 17, 2026, in the Microsoft Store
Version:       1.15.4 (November 25, 2026)
Platform:      Windows 11 (x64)
Price:         One-time purchase, US$7.99; launch price US$4.99 until January 1, 2027. 7-day free trial. Local prices vary.
Languages:     English, German, Spanish, French, Italian, Portuguese (Brazil), Japanese, Korean, Simplified and Traditional Chinese
Privacy:       No account, no ads, no data collected
Contact:       contact@springdesk.app
Website:       https://springdesk.app/
Store:         https://apps.microsoft.com/detail/9NRL4M710KQB

SpringDesk gathers your desktop icons into boxes of clear glass that sit right on the wallpaper and look like they came with Windows 11; even a live wallpaper shows through. Every file you save or download to the desktop goes straight to a tab for its type, so the desktop stays tidy with nothing to set up. Press Space to look inside a file, and Alt+Space anywhere to find anything. Drop one box on another for tabs, roll them up before a call, open a folder's subfolders right inside its box, and double-click the desktop, or just step away, to leave only the wallpaper. Your files never move; SpringDesk only shows them in order. A one-time purchase in the Microsoft Store, with a 7-day free trial.

In this zip
  screenshots/   seven screenshots, 2560 x 1440
  icon/          app icon, 1024 x 1024 and 300 x 300 (pixel art: scale with nearest-neighbor)
  banner.jpg     3840 x 2160
Trailer (40 s, 1080p, with music): https://springdesk.app/press/springdesk-trailer.mp4

Free review codes and questions: contact@springdesk.app
