SpringDesk press kit
https://springdesk.app/press/

SpringDesk is a desktop organizer for Windows 11 that gathers your icons into clear glass boxes, sorts new files by type on its own, and lets you preview or find anything without opening a window.

Developer:     Brock Loong, independent developer
Released:      October 17, 2026, in the Microsoft Store
Version:       1.5.3 (October 22, 2026)
Platform:      Windows 11 (x64)
Price:         One-time purchase, US$7.99; launch price US$4.99 until January 1, 2027. 7-day free trial. Local prices vary.
Languages:     English, Chinese
Privacy:       No account, no ads, no data collected
Website:       https://springdesk.app/
Store:         https://apps.microsoft.com/detail/9NRL4M710KQB

SpringDesk puts the Windows 11 desktop in order. Icons live in translucent boxes that sit on the wallpaper, snap to a grid and never overlap, with tabs, roll-up and folder boxes that show a folder such as Downloads. Every file saved or downloaded to the desktop goes straight to a tab for its type, so the desktop stays tidy without rules to set up. Select an icon and press Space to preview it, as on a Mac, or click the desktop and type to search every box. Files never move: SpringDesk only shows them. It's a one-time purchase in the Microsoft Store with a 7-day free trial.

In this zip
  screenshots/   nine screenshots, 2560 x 1440
  icon/          app icon, 1024 x 1024 and 300 x 300 (pixel art: scale with nearest-neighbor)
  banner.jpg     3840 x 2160
Trailer (55 s, 1080p, no sound): https://springdesk.app/press/springdesk-trailer.mp4

Free review codes and questions: reply to my email, or https://github.com/lchovo/SpringDesk/issues
